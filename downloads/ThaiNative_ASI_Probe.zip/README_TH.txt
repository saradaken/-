ThaiNativeProbe 1.0 — ASI 32 บิตสำหรับตรวจ renderer ของ SA-MP R3

นี่เป็นตัวตรวจสอบ ไม่ใช่ตัวแสดงภาษาไทยที่ทำเสร็จแล้ว
สาเหตุที่ต้องตรวจ: ผลจากสคริปต์ก่อนหน้าพบ wrapperCalls>0 แต่ chatCalls=0 และ hits=0
ปลั๊กอินนี้ตรวจจาก native code เพื่อแยกปัญหา Lua hook กับเส้นทางเรนเดอร์ของไคลเอนต์

วิธีใช้
1. ปิดเกมก่อน เอาไฟล์ ThaiNative/CEFThai รุ่นทดลอง Lua ที่ฉันส่งก่อนหน้าออกจาก moonloader
   ไม่จำเป็นต้องเอาปลั๊กอินเกมอื่นออก เพราะต้องการตรวจสภาพเกมที่คุณใช้จริง
2. วาง ThaiNativeProbe.asi ข้าง gta_sa.exe ต้องมี ASI Loader ที่ใช้งานได้อยู่แล้ว
3. วาง ThaiNativeProbeTest.lua ใน moonloader
4. เข้าเกม พิมพ์ /thasi รอ 15 วินาที แล้วออกเกม
   การเห็น ~THAI_ASI_TEST~ เป็นเรื่องปกติในขั้นตรวจสอบนี้ ยังไม่ได้แปลงเป็นภาษาไทย
5. แนบ ThaiNativeProbe.log ที่อยู่ข้างไฟล์ .asi กลับมาในแชท
   ถ้าสร้างในโฟลเดอร์เกมไม่ได้ จะบันทึกใน %TEMP%\ThaiNativeProbe.log แทน
   กด F10 ในเกมเพื่อบันทึก snapshot เพิ่มได้

บันทึกอะไรบ้าง
- รุ่น PE ของ samp.dll และรายชื่อโมดูลที่โหลด (ชื่อไฟล์ ไม่บันทึกพาธเต็ม)
- byte/signature และเจ้าของฟังก์ชันแชท/ฟอนต์
- ตัวนับการเรียก CChat::RenderText และ wrapper ของฟอนต์
- ตรวจพบรหัสทดสอบ ~TH...~ หรือ [[th:...]] หรือไม่
- ไม่บันทึกข้อความแชททั่วไป ไม่เรียกเครือข่าย ไม่ส่งข้อมูลอัตโนมัติ
- ใช้ MinHook 1.3.4 เพื่อติดตั้งตัวนับที่ function entry แทน vtable hook ของ Lua
- ไม่แทนที่ samp.dll บนดิสก์
- ตรวจลายเซ็นก่อน hook ถ้าไม่ตรงจะรายงานและไม่แก้จุดนั้น
- ปลั๊กอินอยู่จนปิดเกม เมื่อต้องการถอนออกให้ปิดเกมแล้วลบ .asi และ Lua test

ตรวจสอบแล้ว
- cross-compile สำเร็จด้วย MinGW-w64 GCC 14.2 สำหรับ x86
- ซอร์สของปลั๊กอินผ่าน -Wall -Wextra -Werror
- ตัวไฟล์เป็น PE32 DLL x86 และใช้ KERNEL32.dll / USER32.dll / msvcrt.dll
- โครงสร้าง calling convention ตรวจจาก disassembly ของไฟล์ที่คอมไพล์
- ทดสอบ calling convention ของ callback ที่คอมไพล์แล้วด้วยตัวจำลอง x86 ผ่าน
- ยังไม่ได้โหลดใน Windows/เกมจริง ไม่ยืนยันผล renderer จนกว่าจะได้ log

ซอร์สและ build
ThaiNativeProbe.c และ third_party/minhook มาพร้อมในแพ็กเกจนี้
ใช้ GCC สำหรับ Windows x86 เท่านั้น (i686-w64-mingw32-gcc)
คำสั่งสร้างอยู่ใน build.sh
MinHook จาก https://github.com/TsudaKageyu/minhook/tree/v1.3.4 พร้อมไฟล์ LICENSE.txt
