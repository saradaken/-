#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#include "MinHook.h"

/* Native diagnostic only: never replaces chat text or changes network packets. */
static HMODULE g_module;
static FILE *g_log;
static CRITICAL_SECTION g_lock;
static volatile LONG g_chat_calls, g_chat_markers, g_font_calls, g_font_markers;
static volatile LONG g_marker_logs, g_font_zero_count;
typedef void (__attribute__((thiscall)) *ChatFn)(void *, const char *, LONG, LONG, LONG, LONG, DWORD);
typedef int (WINAPI *FontFn)(void *, void *, const char *, int, RECT *, DWORD, DWORD);
static ChatFn g_chat_original;
static FontFn g_font_original;

static void log_line(const char *fmt, ...) {
    va_list args;
    EnterCriticalSection(&g_lock);
    if (g_log) { va_start(args, fmt); vfprintf(g_log, fmt, args); va_end(args); fputc('\n', g_log); fflush(g_log); }
    LeaveCriticalSection(&g_lock);
}
static BOOL read_mem(uintptr_t p, void *dst, SIZE_T n) {
    SIZE_T got=0;
    return p && ReadProcessMemory(GetCurrentProcess(), (const void *)p, dst, n, &got) && got==n;
}
static DWORD read32(uintptr_t p) { DWORD v=0; read_mem(p,&v,4); return v; }
static void owner(uintptr_t p, char *result, SIZE_T size) {
    MEMORY_BASIC_INFORMATION mbi;
    char path[MAX_PATH], *base;
    if (VirtualQuery((const void *)p,&mbi,sizeof(mbi)) && mbi.Type==MEM_IMAGE &&
        GetModuleFileNameA((HMODULE)mbi.AllocationBase,path,sizeof(path))) {
        base=strrchr(path,'\\'); base=base?base+1:path;
        snprintf(result,size,"%s+0x%lX",base,(unsigned long)(p-(uintptr_t)mbi.AllocationBase));
    } else snprintf(result,size,"non-image memory at 0x%08lX",(unsigned long)p);
}
static void describe(const char *label, uintptr_t p) {
    BYTE bytes[16]; char where[MAX_PATH+48], hex[49]; unsigned i;
    owner(p,where,sizeof(where));
    if (!read_mem(p,bytes,sizeof(bytes))) { log_line("%s: unreadable (%s)",label,where); return; }
    for (i=0;i<16;i++) snprintf(hex+i*3,4,"%02X ",bytes[i]);
    log_line("%s: %s bytes=%s",label,where,hex);
    if (bytes[0]==0xE9) {
        int32_t relative; uintptr_t destination;
        memcpy(&relative,bytes+1,4); destination=p+5+relative;
        owner(destination,where,sizeof(where)); log_line("  JMP destination: %s",where);
    }
}
/* Copy at most 160 bytes, without trusting a text pointer or its length. */
static BOOL is_marker(const char *text, int count, const char *source) {
    char sample[161]; SIZE_T got=0,limit=count<0?160:(count>160?160:(SIZE_T)count);
    MEMORY_BASIC_INFORMATION mbi;
    if (!text || !limit || !VirtualQuery(text,&mbi,sizeof(mbi))) return FALSE;
    {SIZE_T remaining=(SIZE_T)((uintptr_t)mbi.BaseAddress+mbi.RegionSize-(uintptr_t)text);if(limit>remaining)limit=remaining;}
    if (!limit || !ReadProcessMemory(GetCurrentProcess(),text,sample,limit,&got) || !got) return FALSE;
    sample[got]=0;
    if (strstr(sample,"~TH") || strstr(sample,"[[th:")) {
        if (InterlockedIncrement(&g_marker_logs)<=10) {
            /* Record only our ASCII marker, not surrounding chat text. */
            char *mark=strstr(sample,"~TH"); char code[25]; SIZE_T j=0;
            if (!mark) mark=strstr(sample,"[[th:");
            while (mark[j] && j<24 && (unsigned char)mark[j]>=32 && (unsigned char)mark[j]<127) {code[j]=mark[j];j++;if(j>1 && code[j-1]=='~')break;}
            code[j]=0;
            log_line("%s saw marker=%s count=%d",source,code,count);
        }
        return TRUE;
    }
    return FALSE;
}
static void __attribute__((fastcall)) chat_hook(void *self, void *unused, const char *text,
    LONG left, LONG top, LONG right, LONG bottom, DWORD color) {
    (void)unused;
    InterlockedIncrement(&g_chat_calls);
    if (is_marker(text,-1,"CChat::RenderText")) InterlockedIncrement(&g_chat_markers);
    g_chat_original(self,text,left,top,right,bottom,color);
}
static int WINAPI font_hook(void *self, void *sprite, const char *text, int count, RECT *rect, DWORD flags, DWORD color) {
    InterlockedIncrement(&g_font_calls);
    if (!count) InterlockedIncrement(&g_font_zero_count);
    /* This SA-MP wrapper ignores Count and reads a NUL-terminated string. */
    if (is_marker(text,-1,"SA-MP font wrapper")) {
        LONG hits=InterlockedIncrement(&g_font_markers);
        if(hits<=10)log_line("Wrapper marker actual Count=%d rect=%p",count,rect);
    }
    return g_font_original(self,sprite,text,count,rect,flags,color);
}
static void modules(void) {
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId()); MODULEENTRY32 m;
    if (snap==INVALID_HANDLE_VALUE) { log_line("Module enumeration failed: %lu",GetLastError()); return; }
    memset(&m,0,sizeof(m));m.dwSize=sizeof(m);
    log_line("Loaded module basenames (no full paths):");
    if (Module32First(snap,&m)) do {log_line("  %s base=%p size=0x%lX",m.szModule,m.modBaseAddr,m.modBaseSize);} while(Module32Next(snap,&m));
    CloseHandle(snap);
}
static void snapshot(BYTE *samp) {
    uintptr_t b=(uintptr_t)samp, chat=read32(b+0x26E8C8), global=read32(b+0x26E8E4);
    uintptr_t live=chat?read32(chat+0x63A2):0; unsigned i;
    log_line("Snapshot tick=%lu chat=%p globalFonts=%p liveFonts=%p",GetTickCount(),(void*)chat,(void*)global,(void*)live);
    log_line("Counters chatCalls=%ld chatMarkers=%ld fontCalls=%ld fontMarkers=%ld zeroCount=%ld",g_chat_calls,g_chat_markers,g_font_calls,g_font_markers,g_font_zero_count);
    describe("CChat::RenderText",b+0x66CF0);
    describe("SA-MP DrawTextA wrapper",b+0x734F0);
    if (!live) return;
    for (i=0;i<4;i++) {
        uintptr_t font=read32(live+i*4), vt=font?read32(font):0;
        char label[64];
        log_line("Font[%u] object=%p vtable=%p",i,(void*)font,(void*)vt);
        if (vt) {snprintf(label,sizeof(label),"Font[%u] DrawTextA slot",i);describe(label,read32(vt+14*4));}
        if (i<2 && vt==b+0xEA3B8) {
            uintptr_t raw=read32(font+4),rawvt=raw?read32(raw):0;
            if (rawvt) {snprintf(label,sizeof(label),"Font[%u] underlying DrawTextA",i);describe(label,read32(rawvt+14*4));}
        }
    }
}
static DWORD WINAPI worker(void *arg) {
    wchar_t path[MAX_PATH]; HMODULE pin,samp=NULL; DWORD i; IMAGE_DOS_HEADER dos; IMAGE_NT_HEADERS32 nt;
    const BYTE chat_expected[6]={0x55,0x8B,0xEC,0x83,0xE4,0xF8};
    const BYTE font_expected[6]={0x8B,0x44,0x24,0x08,0x85,0xC0};
    (void)arg;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCSTR)&worker,&pin);
    if (!GetModuleFileNameW(g_module,path,MAX_PATH-5)) return 1;
    {wchar_t *dot=wcsrchr(path,L'.'); if(dot) *dot=0; wcscat(path,L".log");}
    g_log=_wfopen(path,L"wb");
    if (!g_log) {GetTempPathW(MAX_PATH-32,path);wcscat(path,L"ThaiNativeProbe.log");g_log=_wfopen(path,L"wb");}
    if (!g_log) return 2;
    log_line("ThaiNativeProbe 1.0 x86 — diagnostic only, not a Thai renderer");
    log_line("F10 captures state. Only our ASCII test markers are logged; no other chat contents.");
    for(i=0;i<120 && !samp;i++) {samp=GetModuleHandleA("samp.dll"); if(!samp) Sleep(500);}
    if(!samp){log_line("samp.dll not loaded within 60 seconds");return 3;}
    if (!read_mem((uintptr_t)samp,&dos,sizeof(dos)) || dos.e_magic!=IMAGE_DOS_SIGNATURE || dos.e_lfanew<0x40 || dos.e_lfanew>0x1000 ||
        !read_mem((uintptr_t)samp+dos.e_lfanew,&nt,sizeof(nt)) || nt.Signature!=IMAGE_NT_SIGNATURE) {log_line("Invalid samp.dll PE header");return 4;}
    log_line("samp.dll timestamp=%08lX entry=%08lX imageSize=%08lX",nt.FileHeader.TimeDateStamp,nt.OptionalHeader.AddressOfEntryPoint,nt.OptionalHeader.SizeOfImage);
    modules();
    if(nt.FileHeader.TimeDateStamp!=0x5C0B4243 || nt.OptionalHeader.AddressOfEntryPoint!=0xCC4D0 || nt.OptionalHeader.SizeOfImage!=0x27E000){log_line("Different build: no fixed addresses inspected or hooks installed");return 5;}
    snapshot((BYTE*)samp);
    {
        BYTE bytes[6]; MH_STATUS status=MH_Initialize();
        BOOL queued=FALSE;
        log_line("MinHook initialization: %s",MH_StatusToString(status));
        if(status!=MH_OK) return 6;
        if(read_mem((uintptr_t)samp+0x66CF0,bytes,6) && !memcmp(bytes,chat_expected,6)) {
            status=MH_CreateHook((BYTE*)samp+0x66CF0,(void*)&chat_hook,(void**)&g_chat_original);
            log_line("CChat entry probe creation: %s",MH_StatusToString(status));
            if(status==MH_OK) {status=MH_QueueEnableHook((BYTE*)samp+0x66CF0);log_line("CChat queue: %s",MH_StatusToString(status));if(status==MH_OK)queued=TRUE;}
        } else log_line("CChat prologue differs: left unchanged");
        if(read_mem((uintptr_t)samp+0x734F0,bytes,6) && !memcmp(bytes,font_expected,6)) {
            status=MH_CreateHook((BYTE*)samp+0x734F0,(void*)&font_hook,(void**)&g_font_original);
            log_line("Font entry probe creation: %s",MH_StatusToString(status));
            if(status==MH_OK) {status=MH_QueueEnableHook((BYTE*)samp+0x734F0);log_line("Font queue: %s",MH_StatusToString(status));if(status==MH_OK)queued=TRUE;}
        } else log_line("Font prologue differs: left unchanged");
        if(queued) {status=MH_ApplyQueued();log_line("Probe activation: %s",MH_StatusToString(status));}
    }
    for(i=0;;i++) {
        Sleep(250);
        if((i%40)==0 || (GetAsyncKeyState(VK_F10)&1)) {snapshot((BYTE*)samp);if(GetAsyncKeyState(VK_F10)&0x8000) modules();}
    }
    return 0;
}
__declspec(dllexport) const char *ThaiNativeProbeVersion(void) {return "1.0 diagnostic x86";}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,void *reserved) {
    (void)reserved;
    if(reason==DLL_PROCESS_ATTACH) {
        HANDLE thread; g_module=module;InitializeCriticalSection(&g_lock);DisableThreadLibraryCalls(module);
        thread=CreateThread(NULL,0,worker,NULL,0,NULL);if(thread)CloseHandle(thread);
    }
    return TRUE;
}
