#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
probe_cc=${CC:-i686-w64-mingw32-gcc}
case "$("$probe_cc" -dumpmachine)" in
  i686-w64-mingw32*) ;;
  *) echo 'Use a Windows x86 MinGW-w64 compiler.' >&2; exit 1 ;;
esac
mkdir -p build
"$probe_cc" -O2 -Wall -Wextra -Werror -Ithird_party/minhook/include -c ThaiNativeProbe.c -o build/probe.o
for probe_src in hook buffer trampoline hde/hde32; do
  probe_obj=$(basename "$probe_src")
  "$probe_cc" -O2 -Ithird_party/minhook/include -Ithird_party/minhook/src -c "third_party/minhook/src/$probe_src.c" -o "build/$probe_obj.o"
done
"$probe_cc" -shared -static-libgcc -Wl,--no-insert-timestamp -o ThaiNativeProbe.asi build/probe.o build/hook.o build/buffer.o build/trampoline.o build/hde32.o -luser32
