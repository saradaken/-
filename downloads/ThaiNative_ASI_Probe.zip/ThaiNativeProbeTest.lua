script_name('ThaiNative ASI Probe Test')
function main()
    while not isSampAvailable() do wait(100) end
    sampRegisterChatCommand('thasi', function()
        sampAddChatMessage('[ThaiNativeProbe] BEGIN', -1)
        sampAddChatMessage('~THAI_ASI_TEST~', -1)
        sampAddChatMessage('[ThaiNativeProbe] Wait 15 seconds, exit game, send ThaiNativeProbe.log', -1)
    end)
    sampAddChatMessage('[ThaiNativeProbe] /thasi sends the diagnostic marker.', -1)
    wait(-1)
end
