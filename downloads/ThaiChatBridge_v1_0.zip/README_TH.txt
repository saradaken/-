ThaiChatBridge 1.0 — companion สำหรับ _chat.asi ที่แนบมาโดยตรง

รุ่นทดลองใหม่ ใช้ _chat.asi เป็นตัววาดแชทหลัก ไม่ใช้ renderer ของ ThaiNative รุ่นเก่า
ยังไม่ได้รันใน Windows/เกมจริง จึงยังไม่ยืนยันความเสถียรหรือผลการแสดงวรรณยุกต์

ติดตั้งเพื่อทดสอบ
1. ปิดเกม เอา ThaiNative.asi / ThaiNativeProbe.asi ที่เคยส่งให้ ออกจากการโหลดก่อน
   เอาสคริปต์ CEFThai/ThaiNative รุ่นทดลองก่อนหน้าที่ฉันส่งออกจาก moonloader เพื่อไม่ให้คำสั่ง /thtest ซ้ำกัน
2. เก็บ _chat.asi ของคุณไว้ตามเดิม ไม่ต้องแทนที่ samp.dll หรือ _chat.asi
3. วาง ThaiChatBridge.asi ข้าง gta_sa.exe ต้องมี ASI Loader ที่ใช้งานอยู่แล้ว
4. วาง ThaiChatBridgeTest.lua ใน moonloader สำหรับทดสอบครั้งแรก
5. เปิดเกม รอ 5 วินาที แล้วพิมพ์ /thtest
6. ถ้าแสดงเป็นสี่เหลี่ยม/อักษรหาย ให้ลอง /fontsize 1 เพื่อให้ _chat สร้างฟอนต์ใหม่ แล้ว /thtest อีกครั้ง
   คำสั่งนี้เปลี่ยนขนาดฟอนต์ของ _chat ค่าเดิมของคุณอาจต่างออกไป สามารถตั้งกลับภายหลังได้
7. รอ 15 วินาที แล้วดู ThaiChatBridge.log ที่อยู่ข้าง .asi
   ถ้าโฟลเดอร์เกมเขียนไม่ได้ log จะอยู่ที่ %TEMP%\ThaiChatBridge.log

ค่าใน log
- Installed: ... only = ติดตั้งจุดเชื่อมต่อของ _chat แล้ว ไม่ได้ยืนยันว่าข้อความไทยทำงานในเกมสำเร็จ
- messages > 0 = มีข้อความ marker ที่แปลงเป็น Unicode ไทยแล้ว
- fontMerges > 0 = _chat เพิ่ม glyph ไทยเข้าฟอนต์แล้ว ต้องตรวจในเกมต่อว่า atlas สร้างและแสดงได้จริง
- fontMerges = 0 = ยังไม่เจอการสร้างฟอนต์หลังติดตั้ง ลอง /fontsize 1 แล้วทดสอบอีกครั้ง
- mergeFailures > 0 หรือเกมเด้ง = หยุดใช้ companion แล้วแนบ log และ crash log กลับมา

เหตุผลและสิ่งที่เปลี่ยน
- _chat.asi เป็น ImGui + FreeType ไม่ใช้ ID3DXFont เป็นตัววาดแชท
- ชุด glyph เริ่มต้นมี Latin, Cyrillic, punctuation และไม่มีภาษาไทย
- Hook เฉพาะ AddFontFromMemoryTTF ของ _chat รุ่นที่ตรวจแล้ว
- เมื่อ _chat เพิ่มฟอนต์ข้อความหลัก จะ merge ช่วง U+0E01..U+0E3A และ U+0E3F..U+0E5B จาก Tahoma
- Tahoma อ่านจาก Windows\Fonts\tahoma.ttf บนเครื่องผู้ใช้ ไม่ได้รวมฟอนต์จาก Microsoft ไว้ใน ZIP
- ให้ _chat คัดลอกข้อมูลฟอนต์ด้วย allocator ของมันและเป็นเจ้าของข้อมูลที่คัดลอก
- ไม่ merge ทับ emoji/icon font หรือ config ที่เป็น merge อยู่แล้ว
- เปลี่ยน import slot MultiByteToWideChar ภายใน _chat เพียงโมดูลเดียว
- ไม่มี global Windows conversion hook และไม่มี DrawTextA/W hook
- _chat วาดแชท สี เงา ประวัติ และตำแหน่งเองทั้งหมด

encoding
Lua UTF-8 -> thaiPack -> [[th:<CP874 bytes>]]
_chat import แปลง CP1251/ACP -> Unicode ไทย -> _chat แปลง UTF-8 และวาดผ่าน ImGui/FreeType เดิม
ข้อความนอก marker ใช้ code page เดิม ข้อความปกติใช้ตัวแปลงเดิม
Windows-1251 ไม่มีอักษรไทย การ pack เป็น CP874 run มีไว้ขนส่งผ่าน pipeline เดิมเท่านั้น
เน้นการแสดงผลในเครื่อง ไม่เปลี่ยนโปรโตคอลข้อความที่ส่งไปเซิร์ฟเวอร์

ใช้ระบบคำแปลเดิม
เมื่อทดสอบผ่านแล้ว ใช้ CEFThai_ChatBridge.lua แทน ThaiChatBridgeTest.lua
ใช้ cef_raw.txt เดิมได้ โหลดสคริปต์เพียงตัวเดียวเพราะมี /thtest เหมือนกัน
ตัว local wrapper ทำให้เรียก sampAddChatMessage('สวัสดีครับ', -1) ภายในไฟล์นั้นได้
ไม่ได้เปลี่ยน API ของสคริปต์อื่นโดยอัตโนมัติ

รุ่นที่รองรับ
_chat.asi SHA256 22b3fb9cc4fe4d36ad2b63daaa90ffbd2e6c1006180581186cd5b97849cd1f6c
PE timestamp 6A9589F5, entry C32FA, image size 1CB000
AddFontFromMemoryTTF RVA 6D4A0, ImFontConfig size 78, MergeMode 3C, DstFont 74
Default glyph ranges RVA D6D24, import MultiByteToWideChar RVA CA0F4
ตรวจ PE metadata, prologue และชุด glyph เดิมใน runtime ก่อนติดตั้ง หากไม่ตรงจะไม่ hook
samp.dll ที่แนบล่าสุดเหมือนกับไฟล์ R3 ก่อนหน้า (SHA256 087ed1d0c29b9a9f24443dacddbd3e0ddbc0eadc5673e83e8a9280e72e93dfe5)

การตรวจสอบ
- คอมไพล์ PE32 x86 ด้วย MinGW-w64 GCC, ซอร์ส bridge ผ่าน -Wall -Wextra -Werror
- Lua ทั้งสองไฟล์ผ่าน LuaJIT 2.1
- ทดสอบ conversion callback ที่คอมไพล์แล้วกับ Lua pack ในตัวจำลอง x86
- ทดสอบ bridge ร่วมกับโค้ด AddFontFromMemoryTTF/AddFont จาก _chat.asi ที่แนบจริงในตัวจำลอง
- ยืนยัน calling convention/stack, config 120 bytes, merge ไป font เดิม, Thai ranges, ไม่แก้ config ต้นทาง
- ยืนยัน _chat คัดลอกและถือครองข้อมูล fallback font ด้วย allocator ของมันเอง
- ยืนยันไม่ merge ซ้ำใน icon font หรือ config merge
- ไม่ได้ทดสอบการ rasterize ด้วย FreeType บน Windows หรือการวาด GPU ในเกม
- ImGui/FreeType อาจมีข้อจำกัดการจัดวางวรรณยุกต์ไทย ต้องตรวจผลจริง ไม่ถือว่าเป็น Thai shaping engine ที่สมบูรณ์

มีซอร์ส ThaiChatBridge.c, build.sh และ MinHook 1.3.4 พร้อมใบอนุญาต
ไม่มีไฟล์เกมที่ผู้ใช้แนบรวมอยู่ในแพ็กเกจนี้
