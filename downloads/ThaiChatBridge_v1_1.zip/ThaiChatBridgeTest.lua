script_name('ThaiChatBridge Chat Test')
local ffi=require 'ffi'
-- Requires ThaiChatBridge.asi. UTF-8 Thai is packed as CP874 runs, not CP1251 Thai.
-- This wrapper affects sampAddChatMessage calls in this script only.
ffi.cdef[[void* __stdcall GetModuleHandleA(const char* name);]]
local thaiKernel = ffi.load('kernel32')
local function thaiPack(s)
    local out, run, i = {}, {}, 1
    local function flush()
        if #run > 0 then
            out[#out + 1] = '[[th:' .. table.concat(run) .. ']]'
            run = {}
        end
    end
    while i <= #s do
        local a, b, c = s:byte(i, i + 2)
        local off = a == 0xE0 and (b == 0xB8 or b == 0xB9)
            and c and c >= 0x80 and c <= 0xBF
            and ((b - 0xB8) * 64 + c - 0x80) or nil
        if off and off >= 1 and off <= 0x5B then
            run[#run + 1] = string.char(0xA0 + off)
            i = i + 3
        elseif a == 32 and #run > 0 then
            run[#run + 1] = ' '
            i = i + 1
        else
            flush()
            out[#out + 1] = s:sub(i, i)
            i = i + 1
        end
    end
    flush()
    return table.concat(out)
end


local originalSampAddChatMessage = sampAddChatMessage
local function sampAddChatMessage(text, color)
    if text:find('\224[\184\185][\128-\191]') then
        if thaiKernel.GetModuleHandleA('ThaiChatBridge.asi') == nil then
            return originalSampAddChatMessage('[ThaiChatBridge] ThaiChatBridge.asi is not loaded.', -1)
        end
        return originalSampAddChatMessage(thaiPack(text), color)
    end
    return originalSampAddChatMessage(text, color)
end
local function cmsg(thai, english)
    if thaiKernel.GetModuleHandleA('ThaiChatBridge.asi') ~= nil then sampAddChatMessage(thai,-1)
    else originalSampAddChatMessage(english,-1) end
end

function main()
    while not isSampAvailable() do wait(100) end
    sampRegisterChatCommand('thtest',function()
        sampAddChatMessage('{00FF00}[ThaiChatBridge] สวัสดีครับ นี่คือภาษาไทยในแชทเดิม',-1)
        sampAddChatMessage('{FFD24A}[ThaiChatBridge] ก่อน ก้อน กิ่ง กี่ น้ำ ผู้เล่น',-1)
        originalSampAddChatMessage('[ThaiChatBridge] Wait 15 seconds, then check ThaiChatBridge.log.',-1)
    end)
    originalSampAddChatMessage('[ThaiChatBridge] /thtest',-1)
    wait(-1)
end
