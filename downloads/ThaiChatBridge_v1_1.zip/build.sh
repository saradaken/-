#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
bridge_cc=${CC:-i686-w64-mingw32-gcc}
case "$("$bridge_cc" -dumpmachine)" in i686-w64-mingw32*) ;; *) echo 'Windows x86 compiler required' >&2; exit 1;; esac
mkdir -p build
"$bridge_cc" -O2 -Wall -Wextra -Werror -Ithird_party/minhook/include -c ThaiChatBridge.c -o build/bridge.o
for bridge_src in hook buffer trampoline hde/hde32; do
 bridge_obj=$(basename "$bridge_src")
 "$bridge_cc" -O2 -Ithird_party/minhook/include -Ithird_party/minhook/src -c "third_party/minhook/src/$bridge_src.c" -o "build/$bridge_obj.o"
done
"$bridge_cc" -shared -static-libgcc -Wl,--no-insert-timestamp -o ThaiChatBridge.asi build/bridge.o build/hook.o build/buffer.o build/trampoline.o build/hde32.o
