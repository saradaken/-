#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
renderer_cc=${CC:-i686-w64-mingw32-gcc}
case "$("$renderer_cc" -dumpmachine)" in i686-w64-mingw32*) ;; *) echo 'Windows x86 compiler required' >&2; exit 1;; esac
mkdir -p build
"$renderer_cc" -O2 -Wall -Wextra -Werror -Ithird_party/minhook/include -c ThaiNative.c -o build/native.o
for renderer_src in hook buffer trampoline hde/hde32; do
 renderer_obj=$(basename "$renderer_src")
 "$renderer_cc" -O2 -Ithird_party/minhook/include -Ithird_party/minhook/src -c "third_party/minhook/src/$renderer_src.c" -o "build/$renderer_obj.o"
done
"$renderer_cc" -shared -static-libgcc -Wl,--no-insert-timestamp -o ThaiNative.asi build/native.o build/hook.o build/buffer.o build/trampoline.o build/hde32.o
