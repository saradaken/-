script_name('CEFThai + Native ASI Font Bridge')
script_author('SARADAKEN & OpenAI')
script_description('CEF Thai translation: exact match, auto-reload, and grouping of inline pieces into one phrase')

local encoding = require 'encoding'
encoding.default = 'CP1251'
local ffi = require 'ffi'

pcall(ffi.cdef, [[
int OpenClipboard(void* hWndNewOwner);
int CloseClipboard(void);
void* GetClipboardData(unsigned int uFormat);
void* GlobalLock(void* hMem);
int GlobalUnlock(void* hMem);
int WideCharToMultiByte(unsigned int CodePage, unsigned long dwFlags, const wchar_t* lpWideCharStr, int cchWideChar, char* lpMultiByteStr, int cbMultiByte, const char* lpDefaultChar, int* lpUsedDefaultChar);

typedef void* HINTERNET;
HINTERNET InternetOpenA(const char* agent, unsigned long accessType, const char* proxy, const char* bypass, unsigned long flags);
HINTERNET InternetOpenUrlA(HINTERNET h, const char* url, const char* headers, unsigned long headersLen, unsigned long flags, uintptr_t context);
int InternetReadFile(HINTERNET f, void* buf, unsigned long toRead, unsigned long* read);
int InternetCloseHandle(HINTERNET h);

typedef struct _FILETIME {
    unsigned long dwLowDateTime;
    unsigned long dwHighDateTime;
} FILETIME, *PFILETIME;

typedef struct _WIN32_FILE_ATTRIBUTE_DATA {
    unsigned long dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    unsigned long fileSizeHigh;
    unsigned long fileSizeLow;
} WIN32_FILE_ATTRIBUTE_DATA, *PWIN32_FILE_ATTRIBUTE_DATA;

int GetFileAttributesExA(const char* lpFileName, int fInfoLevelId, void* lpFileInformation);
]])

local wi = ffi.load('wininet')


-- Requires ThaiNative.asi. UTF-8 Thai is packed as CP874 runs, not CP1251 Thai.
-- This wrapper affects sampAddChatMessage calls in this script only.
ffi.cdef[[void* __stdcall GetModuleHandleA(const char* name);]]
local thaiKernel = ffi.load('kernel32')
local function thaiPack(s)
    local out, run, i = {}, {}, 1
    local function flush()
        if #run > 0 then
            out[#out + 1] = '[[th:' .. table.concat(run) .. ']]'
            run = {}
        end
    end
    while i <= #s do
        local a, b, c = s:byte(i, i + 2)
        local off = a == 0xE0 and (b == 0xB8 or b == 0xB9)
            and c and c >= 0x80 and c <= 0xBF
            and ((b - 0xB8) * 64 + c - 0x80) or nil
        if off and off >= 1 and off <= 0x5B then
            run[#run + 1] = string.char(0xA0 + off)
            i = i + 3
        elseif a == 32 and #run > 0 then
            run[#run + 1] = ' '
            i = i + 1
        else
            flush()
            out[#out + 1] = s:sub(i, i)
            i = i + 1
        end
    end
    flush()
    return table.concat(out)
end


local originalSampAddChatMessage = sampAddChatMessage
local function sampAddChatMessage(text, color)
    if text:find('\224[\184\185][\128-\191]') then
        if thaiKernel.GetModuleHandleA('ThaiNative.asi') == nil then
            return originalSampAddChatMessage('[ThaiNative] ThaiNative.asi is not loaded.', -1)
        end
        return originalSampAddChatMessage(thaiPack(text), color)
    end
    return originalSampAddChatMessage(text, color)
end
local function cmsg(thai, english)
    if thaiKernel.GetModuleHandleA('ThaiNative.asi') ~= nil then sampAddChatMessage(thai,-1)
    else originalSampAddChatMessage(english,-1) end
end

-- =====================================================================
-- CONFIG & PATHS
-- =====================================================================
local ROOT = getWorkingDirectory()
local RAW_FILE = ROOT .. '\\cef_raw.txt'
local CHUNK = 10000
local PREFIX = '__CEFTHAI_RAW_V2__'
local emulating = false
local captureOn = true

local rawList, rawIndex = {}, {}
local rawCount, thCount = 0, 0
local nextInject = nil
local lastFileWriteLow = 0
local lastFileWriteHigh = 0

-- =====================================================================
-- HELPER FUNCTIONS
-- =====================================================================
local function trim(s) return (s:gsub('^%s+', ''):gsub('%s+$', '')) end
local function hasCyr(s) return s:find('[\208\209][\128-\191]') ~= nil end
local function hasThai(s) return s:find('\224[\184\185][\128-\191]') ~= nil end

local function getFileWriteTime(path)
    local info = ffi.new('WIN32_FILE_ATTRIBUTE_DATA')
    if ffi.C.GetFileAttributesExA(path, 0, info) ~= 0 then
        return info.ftLastWriteTime.dwLowDateTime, info.ftLastWriteTime.dwHighDateTime
    end
    return 0, 0
end

local function jsString(s)
    local out, i = {}, 1
    while i <= #s do
        local b = s:byte(i)
        if b == 34 then out[#out + 1] = '\\"'; i = i + 1
        elseif b == 92 then out[#out + 1] = '\\\\'; i = i + 1
        elseif b == 10 then out[#out + 1] = '\\n'; i = i + 1
        elseif b == 13 then out[#out + 1] = '\\r'; i = i + 1
        elseif b == 9 then out[#out + 1] = '\\t'; i = i + 1
        elseif b < 32 then out[#out + 1] = string.format('\\u%04x', b); i = i + 1
        elseif b < 128 then out[#out + 1] = string.char(b); i = i + 1
        else
            local cp, n
            local function cont(k) return (s:byte(k) or 0x80) - 0x80 end
            if b < 0xE0 then cp, n = (b - 0xC0) * 64 + cont(i + 1), 2
            elseif b < 0xF0 then cp, n = (b - 0xE0) * 4096 + cont(i + 1) * 64 + cont(i + 2), 3
            else cp, n = (b - 0xF0) * 262144 + cont(i + 1) * 4096 + cont(i + 2) * 64 + cont(i + 3), 4 end
            if cp >= 0x10000 then
                cp = cp - 0x10000
                out[#out + 1] = string.format('\\u%04x\\u%04x', 0xD800 + math.floor(cp / 1024), 0xDC00 + (cp % 1024))
            else
                out[#out + 1] = string.format('\\u%04x', cp)
            end
            i = i + n
        end
    end
    return '"' .. table.concat(out) .. '"'
end

local function ensureFile()
    local f = io.open(RAW_FILE, 'ab'); if f then f:close() end
end

local function loadRaw()
    ensureFile()
    local list, index, translated = {}, {}, 0
    local f = io.open(RAW_FILE, 'rb')
    if f then
        local data = f:read('*a'); f:close()
        data = data:gsub('^\239\187\191', '')
        for line in data:gmatch('[^\r\n]+') do
            local ru, th = line:match('\ttext=([^\t]*)\tth=(.*)$')
            if not ru then ru = line:match('\ttext=([^\t]*)'); th = '' end
            if ru then
                ru = trim(ru); th = trim(th or '')
                if ru ~= '' and not hasThai(ru) then
                    local idx = index[ru]
                    if not idx then
                        list[#list + 1] = { ru = ru, th = th }
                        index[ru] = #list
                    elseif th ~= '' then
                        list[idx].th = th
                    end
                end
            end
        end
    end
    for _, e in ipairs(list) do if e.th ~= '' then translated = translated + 1 end end
    rawList, rawIndex, thCount = list, index, translated
    lastFileWriteLow, lastFileWriteHigh = getFileWriteTime(RAW_FILE)
end

-- =====================================================================
-- CEF INJECTION CORE (Exact Match ทั้งหมด)
-- =====================================================================
local CORE = [==[
(function(){
var VERSION=9;
if(window.__cefthai2&&window.__cefthai2.version===VERSION)return;
if(window.__cefthai2&&window.__cefthai2.observer){try{window.__cefthai2.observer.disconnect();}catch(e){}}
var S=window.__cefthai2={version:VERSION,dict:Object.create(null),seen:Object.create(null),observer:null,queue:[],timer:null,fail:0,capture:true};
var CY=/[\u0400-\u04FF]/;
var SKIP={SCRIPT:1,STYLE:1,TEXTAREA:1,INPUT:1,NOSCRIPT:1};
function norm(s){return String(s||'').replace(/\s+/g,' ').trim();}
S.clear=function(){S.dict=Object.create(null);S.seen=Object.create(null);};
S.add=function(list){for(var i=0;i<list.length;i++){var k=norm(list[i][0]);if(!k)continue;S.dict[k]=list[i][1]||'';S.seen[k]=1;}};
function logRaw(s){
 if(!S.capture||s.length>600||s.length<2||S.seen[s])return;
 if(/[\u0E00-\u0E7F]/.test(s))return;
 S.seen[s]=1;S.queue.push(s);
 if(!S.timer)S.timer=setTimeout(flush,600);
}
function flush(){
 S.timer=null;
 if(!S.capture||!S.queue.length)return;
 var batch=S.queue.slice(0,35),ae=document.activeElement,ta=document.createElement('textarea');
 ta.value='__CEFTHAI_RAW_V2__\n'+batch.join('\n');
 ta.setAttribute('readonly','');
 ta.style.cssText='position:fixed;left:1px;top:1px;width:2px;height:2px;opacity:.02;z-index:2147483647';
 document.body.appendChild(ta);
 var ok=false;
 try{ta.focus();ta.select();ok=document.execCommand('copy')===true;}catch(e){}
 ta.remove();
 if(ae&&ae!==document.body&&ae.focus){try{ae.focus();}catch(e){}}
 if(ok){S.fail=0;S.queue.splice(0,batch.length);}
 else{S.fail++;if(S.fail>=3){S.fail=0;S.queue=[];}}
 if(S.queue.length)S.timer=setTimeout(flush,ok?500:1500);
}
var INLINE={SPAN:1,B:1,STRONG:1,I:1,EM:1,FONT:1,A:1,SMALL:1,U:1,MARK:1,S:1,DEL:1,SUB:1,SUP:1,LABEL:1,CODE:1,BR:1,BIG:1,ABBR:1};
function hasText(el){
 for(var c=el.firstChild;c;c=c.nextSibling){
  if(c.nodeType===3){if(norm(c.nodeValue))return true;}
  else if(c.nodeType===1&&hasText(c))return true;
 }
 return false;
}
function collect(el,out){
 for(var c=el.firstChild;c;c=c.nextSibling){
  if(c.nodeType===3){if(norm(c.nodeValue)){out.push(c);if(out.length>8)return false;}}
  else if(c.nodeType===1){
   if(SKIP[c.nodeName])return false;
   if(INLINE[c.nodeName]){if(!collect(c,out))return false;}
   else if(hasText(c))return false;
  }
 }
 return true;
}
function plainInline(el,top){
 for(var e=el;e&&e!==top;e=e.parentNode){
  if(e.nodeType!==1)return false;
  var d=window.getComputedStyle(e).display;
  if(d!=='inline'&&d!=='contents')return false;
 }
 return true;
}
function groupOf(node){
 var e=node.parentNode;
 while(e&&e.nodeType===1&&INLINE[e.nodeName]&&e.parentNode&&e.parentNode.nodeType===1)e=e.parentNode;
 if(!e||e.nodeType!==1||e===document.body||e===document.documentElement)return null;
 var segs=[];
 if(!collect(e,segs)||segs.length<2)return null;
 if(/flex|grid/.test(window.getComputedStyle(e).display))return null;
 for(var j=0;j<segs.length;j++){if(!plainInline(segs[j].parentNode,e))return null;}
 var parts=[],cy=0,i,t;
 for(i=0;i<segs.length;i++){t=norm(segs[i].nodeValue);parts.push(t);if(CY.test(t))cy++;}
 if(cy<2)return null;
 var key=parts.join(' ');
 if(key.length>300)return null;
 return {segs:segs,key:key};
}
function applyGroup(g,th){
 g.segs[0].nodeValue=th;
 for(var i=1;i<g.segs.length;i++)g.segs[i].nodeValue='';
}
function translateText(node){
 var old=node.nodeValue;
 if(!old||!CY.test(old))return;
 var p=node.parentNode;
 if(p){if(SKIP[p.nodeName])return;if(p.isContentEditable)return;}
 var g=groupOf(node);
 if(g){
  var gt=S.dict[g.key];
  if(gt!==undefined&&gt!==''){if(gt!==g.key)applyGroup(g,gt);return;}
  if(gt===undefined)logRaw(g.key);
  return;
 }
 var s=norm(old);
 if(!s)return;
 var th=S.dict[s];
 if(th===undefined){logRaw(s);return;}
 if(!th||th===s)return;
 node.nodeValue=old.indexOf(s)>=0?old.replace(s,function(){return th;}):th;
}
function walk(root){
 if(!root)return;
 if(root.nodeType===3){translateText(root);return;}
 if(root.nodeType!==1&&root.nodeType!==9&&root.nodeType!==11)return;
 var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null),n;
 while((n=w.nextNode()))translateText(n);
}
S.scan=function(){if(document.body)walk(document.body);};
S.observer=new MutationObserver(function(ms){
 ms.forEach(function(m){
  if(m.type==='characterData')translateText(m.target);
  else m.addedNodes.forEach(function(n){walk(n);});
 });
});
if(document.body){S.observer.observe(document.body,{childList:true,subtree:true,characterData:true});S.scan();}
})();
]==]
CORE = CORE:gsub('\n%s*', '\n')

local function readBytes(bs, len)
    local t = {}; for i = 1, len do t[i] = string.char(raknetBitStreamReadInt8(bs) % 256) end; return table.concat(t)
end

local function readCefString(bs)
    raknetBitStreamResetReadPointer(bs); raknetBitStreamIgnoreBits(bs, 8)
    if raknetBitStreamReadInt8(bs) ~= 17 then raknetBitStreamResetReadPointer(bs); return nil end
    raknetBitStreamIgnoreBits(bs, 32)
    local length = raknetBitStreamReadInt16(bs); local encoded = raknetBitStreamReadInt8(bs); local str
    if not length or length < 0 or length > 32000 then raknetBitStreamResetReadPointer(bs); return nil end
    if encoded ~= 0 then str = raknetBitStreamDecodeString(bs, length + encoded) else str = readBytes(bs, length) end
    raknetBitStreamResetReadPointer(bs); return str
end

local function sendToCEF(str)
    if #str > 32000 then return end
    local bs = raknetNewBitStream(); raknetBitStreamWriteInt8(bs, 17); raknetBitStreamWriteInt32(bs, 0)
    raknetBitStreamWriteInt16(bs, #str); raknetBitStreamWriteInt8(bs, 0); raknetBitStreamWriteString(bs, str)
    emulating = true; raknetEmulPacketReceiveBitStream(220, bs); emulating = false; raknetDeleteBitStream(bs)
end

local function injectAll(force)
    if force then
        sendToCEF('if(window.__cefthai2&&window.__cefthai2.observer){window.__cefthai2.observer.disconnect();}window.__cefthai2=null;')
    end
    sendToCEF(CORE)
    sendToCEF('window.__cefthai2&&window.__cefthai2.clear();')
    sendToCEF('window.__cefthai2&&(window.__cefthai2.capture=' .. tostring(captureOn) .. ');')
    
    local arr, size = {}, 0
    local function flushArr()
        if #arr > 0 then
            sendToCEF('window.__cefthai2&&window.__cefthai2.add([' .. table.concat(arr, ',') .. ']);')
            arr, size = {}, 0
        end
    end
    for _, e in ipairs(rawList) do
        local item = '[' .. jsString(e.ru) .. ',' .. jsString(e.th) .. ']'
        if size + #item > CHUNK then flushArr() end
        arr[#arr + 1] = item; size = size + #item + 1
    end
    flushArr()
    sendToCEF('window.__cefthai2&&window.__cefthai2.scan();')
end

-- =====================================================================
-- CAPTURE & PACKET PROCESSOR (จับข้อความแบบเต็มคำ ไม่ตัดแต่ง)
-- =====================================================================
local function appendUniqueRaw(s, source)
    s = trim((s or ''):gsub('%c', ' '))
    if s == '' or not hasCyr(s) or #s > 600 then return false end
    if hasThai(s) then return false end
    if rawIndex[s] then return false end
    
    local f = io.open(RAW_FILE, 'ab'); if not f then return false end
    f:write('source=', source or 'unknown', '\ttext=', s, '\tth=\r\n'); f:close()
    rawList[#rawList + 1] = { ru = s, th = '' }
    rawIndex[s] = #rawList
    rawCount = rawCount + 1
    return true
end

local function extractRussian(str)
    local out = {}
    for v in str:gmatch('"([^"\r\n]+)"') do
        v = trim(v); if #v >= 2 and #v <= 600 and hasCyr(v) then out[#out + 1] = v end
    end
    if #out == 0 and hasCyr(str) and #str <= 600 then out[1] = str end
    return out
end

local function collectPacket(str)
    for _, v in ipairs(extractRussian(str)) do appendUniqueRaw(v, 'packet') end
end

local function getClipboard()
    if ffi.C.OpenClipboard(nil) == 0 then return nil end
    local res; local h = ffi.C.GetClipboardData(13)
    if h ~= nil then
        local p = ffi.C.GlobalLock(h)
        if p ~= nil then
            local w = ffi.cast('const wchar_t*', p); local n = ffi.C.WideCharToMultiByte(65001, 0, w, -1, nil, 0, nil, nil)
            if n > 1 then
                local buf = ffi.new('char[?]', n); ffi.C.WideCharToMultiByte(65001, 0, w, -1, buf, n, nil, nil); res = ffi.string(buf, n - 1)
            end
            ffi.C.GlobalUnlock(h)
        end
    end
    ffi.C.CloseClipboard(); return res
end

local lastClipboard = ''
local function collectClipboard()
    if not captureOn then return end
    local ok, clip = pcall(getClipboard)
    if not ok or not clip or clip == '' or clip == lastClipboard then return end
    if clip:sub(1, #PREFIX) ~= PREFIX then return end
    lastClipboard = clip
    local first = true
    for line in clip:gmatch('[^\r\n]+') do
        if first then first = false else appendUniqueRaw(line, 'dom') end
    end
end

function onReceivePacket(id, bs)
    if id ~= 220 or emulating then return end
    local str = readCefString(bs)
    if str and captureOn then pcall(collectPacket, str) end
    if str and str:find('setActiveView', 1, true) then nextInject = os.clock() + 0.8 end
end

local thaiEventsOk, thaiEvents = pcall(require, 'samp.events')
local function translateNativeChat(text)
    local ok, utf = pcall(function() return encoding.UTF8(text) end)
    if not ok then return nil end
    local key = trim(utf:gsub('{%x%x%x%x%x%x}', '')):gsub('%s+', ' ')
    local idx = rawIndex[key]
    if idx and rawList[idx].th ~= '' and thaiKernel.GetModuleHandleA('ThaiNative.asi') ~= nil then
        return thaiPack(rawList[idx].th)
    end
    if captureOn then appendUniqueRaw(key, 'native_chat') end
end
if thaiEventsOk then
    function thaiEvents.onServerMessage(color,text)
        local translated=translateNativeChat(text)
        if translated then return {color,translated} end
    end
    function thaiEvents.onChatMessage(playerId,text)
        local translated=translateNativeChat(text)
        if translated then return {playerId,translated} end
    end
end

-- =====================================================================
-- MAIN
-- =====================================================================
function main()
    while not isSampAvailable() do wait(100) end
    loadRaw()
    
    sampRegisterChatCommand('thtest', function()
        sampAddChatMessage('{00FF00}[ThaiNative] สวัสดีครับ นี่คือภาษาไทยในแชทเดิม', -1)
        sampAddChatMessage('{FFD24A}[ThaiNative] ก่อน ก้อน กิ่ง กี่ น้ำ ผู้เล่น', -1)
        originalSampAddChatMessage('[ThaiNative] Renderer counters are in ThaiNative.log (wait 15 seconds).', -1)
    end)
    sampRegisterChatCommand('threload', function()
        loadRaw(); injectAll(true)
        cmsg('{00FF00}[CEFThai] โหลดไฟล์สำเร็จ (Exact Mode) ' .. #rawList .. ' แถว, แปลแล้ว: ' .. thCount, '{00FF00}[CEFThai] Loaded ' .. #rawList .. ' rows, translated: ' .. thCount)
    end)
    sampRegisterChatCommand('thfile', function() cmsg('{00FF00}[CEFThai] ตำแหน่งไฟล์: ' .. RAW_FILE, '{00FF00}[CEFThai] File: ' .. RAW_FILE) end)
    sampRegisterChatCommand('thstat', function()
        sampAddChatMessage('{00FF00}[CEFThai] lines=' .. #rawList .. ' translated=' .. thCount .. ' new=' .. rawCount .. ' capture=' .. tostring(captureOn), -1)
    end)
    sampRegisterChatCommand('thcap', function()
        captureOn = not captureOn
        sendToCEF('window.__cefthai2&&(window.__cefthai2.capture=' .. tostring(captureOn) .. ');')
        sampAddChatMessage('{00FF00}[CEFThai] capture = ' .. tostring(captureOn), -1)
    end)

    cmsg('{00FF00}[CEFThai] โหลดระบบ CEFThai Exact Mode เรียบร้อย', '{00FF00}[CEFThai] CEFThai Exact Mode ready')
    
    wait(3000)
    injectAll(true)
    
    local lastPoll = 0
    local fileCheckTimer = 0
    while true do
        wait(100)
        local now = os.clock()
        
        if now - lastPoll >= 0.5 then 
            lastPoll = now; 
            collectClipboard() 
        end
        
        if now - fileCheckTimer >= 2.0 then
            fileCheckTimer = now
            local low, high = getFileWriteTime(RAW_FILE)
            if low ~= lastFileWriteLow or high ~= lastFileWriteHigh then
                loadRaw()
                injectAll(true)
                cmsg('{00FF00}[CEFThai] ตรวจพบการอัปเดตคำแปล รีโหลดเข้าเกมให้อัตโนมัติแล้ว!', '{00FF00}[CEFThai] Translations updated, reloaded!')
            end
        end

        if nextInject and now >= nextInject then 
            nextInject = nil; 
            injectAll(false) 
        end
    end
end